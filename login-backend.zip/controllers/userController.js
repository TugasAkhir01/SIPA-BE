const User = require('../models/userModel');
const bcrypt = require('bcryptjs');

exports.createUser = async (req, res) => {
    const { nama, email, password, role, nim, nip } = req.body;
    if (!password) return res.status(400).json({ message: 'Password wajib diisi' });

    const hashedPassword = await bcrypt.hash(password, 10);
    User.create({ nama, email, password: hashedPassword, role, nim, nip }, (err, result) => {
        if (err) return res.status(500).json({ message: 'Gagal membuat user', error: err });
        res.status(201).json({ message: 'User berhasil dibuat', userId: result.insertId });
    });
};

exports.getAllUsers = (req, res) => {
    User.findAll((err, users) => {
        if (err) return res.status(500).json({ message: 'Gagal mengambil data', error: err });
        res.status(200).json(users);
    });
};

exports.getUserById = (req, res) => {
    User.findById(req.params.id, (err, user) => {
        if (err) return res.status(500).json({ message: 'Gagal mengambil data', error: err });
        if (!user.length) return res.status(404).json({ message: 'User tidak ditemukan' });
        res.status(200).json(user[0]);
    });
};

exports.updateUser = (req, res) => {
    const { nama, email, role, nip, photo } = req.body;
    const id = req.params.id;

    User.update(id, { nama, email, role, nip, photo }, (err) => {
        if (err) return res.status(500).json({ message: 'Gagal memperbarui user', error: err });

        User.findById(id, (err, result) => {
            if (err) return res.status(500).json({ message: 'Gagal mengambil data user', error: err });
            if (!result.length) return res.status(404).json({ message: 'User tidak ditemukan setelah update' });

            res.status(200).json({
                message: 'User berhasil diperbarui',
                user: result[0]
            });
        });
    });
};


exports.deleteUser = (req, res) => {
    User.delete(req.params.id, (err) => {
        if (err) return res.status(500).json({ message: 'Gagal menghapus user', error: err });
        res.status(200).json({ message: 'User berhasil dihapus' });
    });
};
