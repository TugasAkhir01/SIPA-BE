const db = require('../config/db');

exports.create = (user, callback) => {
    const { nama, email, password, role, nip } = user;
    const photo = user.photo || null;

    const query = `INSERT INTO users (nama, email, password, role, nip, photo) VALUES (?, ?, ?, ?, ?, ?)`;
    db.query(query, [nama, email, password, role, nip, photo], callback);
};

exports.findAll = (callback) => {
    db.query('SELECT id, nama, email, role, nip, photo FROM users', callback);
};

exports.findById = (id, callback) => {
    db.query('SELECT id, nama, email, role, nip, photo FROM users WHERE id = ?', [id], callback);
};

exports.update = (id, user, callback) => {
    const { nama, email, role, nip, photo } = user;
    const query = `UPDATE users SET nama = ?, email = ?, role = ?, nip = ?, photo = ? WHERE id = ?`;
    db.query(query, [nama, email, role, nip, photo, id], callback);
};

exports.delete = (id, callback) => {
    db.query('DELETE FROM users WHERE id = ?', [id], callback);
};
